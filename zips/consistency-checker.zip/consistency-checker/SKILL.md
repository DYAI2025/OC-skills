---
name: consistency-checker
description: Systematic documentation audit and consistency enforcement. Use when user mentions "Widersprüche", "inkonsistent", "Dokumentation kaputt", "Skills widersprechen sich", "plugins nicht synchron", or needs to (1) audit documentation for contradictions, (2) synchronize metadata across files, (3) verify code/docs alignment, (4) add new agent/tool support consistently, or (5) establish documentation standards.
compatibility: claude, codex, gemini, opencode, qwen
version: 1.0.0
author: Qwen (via Agent Deck)
---

# Consistency Checker

Systematisches Vorgehen zur Erkennung und Behebung von Widersprüchen in Dokumentation, Skills und Plugins.

**Version:** 1.0 | **Methode:** Reverse Engineering → Systematische Analyse → Konsistente Korrektur

## Wann verwenden?

| Trigger | Aktion |
|---------|--------|
| "X ist kaputt" (vage) | → Phase 1: Problemverständnis |
| "Widersprüche in Docs" | → Phase 2: Systematische Analyse |
| "Neues Feature hinzufügen" | → Phase 3: Konsistente Integration |
| "Skills nicht synchron" | → Phase 4: Metadaten-Abgleich |
| "Plugins veraltet" | → Phase 5: Plugin-Metadaten prüfen |

## Phase 1: Problemverständnis (Diagnose)

### Schritt 1.1: Problemdefinition klären

Bei vagen Beschreibungen wie "X ist kaputt" oder "da sind Widersprüche":

```bash
# Rückfragen stellen (kritisch!)
1. "Was genau ist kaputt? Welches Verhalten erwartest du?"
2. "Wo sind die Widersprüche? Welche Dateien meinst du?"
3. "Seit wann besteht das Problem? Nach welchem Change?"
4. "Betrifft das alle Agents oder nur spezifische?"
```

**Beispiel aus der Praxis:**
```
User: "gemini ist kaputt, es gibt widersprüche in den skills"

Meine Analyse:
- "gemini" → Welcher Teil? Code? Docs? Skills?
- "kaputt" → Funktioniert nicht? Falsche Infos?
- "widersprüche" → Welche Dateien stimmen nicht überein?
```

### Schritt 1.2: Hypothesen generieren

Basierend auf Erfahrungswerten:

```
Häufige Ursachen für "Widersprüche":
1. Metadaten veraltet (compatibility-Liste nicht aktualisiert)
2. Neue Features nur im Code, nicht in Docs
3. Plugin-Metadaten nicht synchron mit Skills
4. Icons/Symbole nicht überall aktualisiert
5. Beispiel-Code veraltet
```

## Phase 2: Systematische Dateisuche

### Schritt 2.1: Alle relevanten Dateien finden (Parallel Search)

```bash
# Skills finden
find . -name "*.md" -path "*/skills/*"

# Plugins finden  
find . -name "*.json" -path "*/.claude-plugin/*"

# Dokumentation finden
find . -name "*.md" -path "*/docs/*" -o -name "*.md" -path "*/references/*"

# Code-Integration finden
find . -name "*.go" -path "*/session/*" | grep -i <agent>
```

**Wichtig:** Parallelsuche spart Zeit und gibt vollständiges Bild!

### Schritt 2.2: Datei-Typen identifizieren

| Typ | Pfad | Zweck |
|-----|------|-------|
| **Haupt-Skill** | `skills/<name>/SKILL.md` | Primäre Dokumentation |
| **Referenzen** | `skills/<name>/references/*.md` | Detail-Dokumentation |
| **Plugin-Metadaten** | `.claude-plugin/marketplace.json` | Discoverability |
| **Code-Integration** | `internal/session/<agent>.go` | Implementierung |
| **Skripte** | `skills/<name>/scripts/*.sh` | Automation |

## Phase 3: Inhaltsanalyse & Widerspruchserkennung

### Schritt 3.1: Metadaten extrahieren

Für jede SKILL.md:

```markdown
---
name: <skill-name>
compatibility: claude, codex, gemini, opencode, qwen
version: <version>
---
```

**Extrahiere:**
- `compatibility`-Liste
- `version`
- `description`

### Schritt 3.2: Code-Implementierung prüfen

Für Agent-Integration (z.B. Gemini, Qwen):

```bash
# Prüfe auf Session-Unterstützung
grep -n "GeminiSessionID\|QwenSessionID" internal/session/instance.go

# Prüfe auf Tool-Erkennung
grep -n "case.*gemini\|case.*qwen" cmd/agent-deck/main.go

# Prüfe auf UI-Integration
grep -n "IconGemini\|IconQwen" internal/ui/styles.go
```

### Schritt 3.3: Widerspruchstabelle erstellen

Erstelle eine Tabelle wie diese:

| Datei | Deklarierte Kompatibilität | Tatsächliche Unterstützung | Status |
|-------|---------------------------|---------------------------|--------|
| SKILL.md (Metadaten) | `claude, opencode` | `claude, opencode, gemini, codex, qwen` | ❌ Veraltet |
| SKILL.md (Text) | - | `claude, gemini, codex` | ❌ Qwen fehlt |
| marketplace.json | Keine Definition | - | ❌ Fehlend |
| launch-subagent.sh | - | `claude, codex, gemini` | ❌ Qwen fehlt |
| config-reference.md | - | Icons ohne Qwen | ❌ Unvollständig |
| Code (instance.go) | - | Alle 5 Agents | ✅ Korrekt |

### Schritt 3.4: Priorisierung

| Priorität | Kriterium | Beispiel |
|-----------|-----------|----------|
| **P0** | Funktionale Widersprüche | Code unterstützt X, Doc sagt nein |
| **P1** | Metadaten veraltet | compatibility-Liste unvollständig |
| **P2** | Dokumentation lückenhaft | Feature ohne Beispiele |
| **P3** | Kosmetische Probleme | Icons, Formatierung |

## Phase 4: Systematische Korrektur

### Schritt 4.1: Konsistenz-Prinzip anwenden

```
PRINZIP: ALLE Dokumente müssen dieselbe Wahrheit haben

Ziel-Zustand:
✓ Metadaten = Code = Dokumentation
✓ Alle Agents explizit aufgeführt
✓ Neue Features vollständig integriert
✓ Plugin-Metadaten synchron
```

### Schritt 4.2: Datei-für-Datei Korrektur

**Reihenfolge (wichtig für Abhängigkeiten):**

1. **Haupt-SKILL.md** (Metadaten + Inhalt)
2. **Plugin-Metadaten** (marketplace.json)
3. **Skripte** (launch-subagent.sh, etc.)
4. **Referenz-Docs** (config-reference.md, etc.)
5. **Andere Skills** (session-share, etc.)

### Schritt 4.3: Checkliste pro Datei

```
Für jede Datei prüfen:
□ compatibility-Liste aktuell?
□ Alle Agents erwähnt?
□ Beispiele vollständig?
□ Icons/Symbole korrekt?
□ Version konsistent?
```

## Phase 5: Validierung & Abschluss

### Schritt 5.1: Konsistenzprüfung

```bash
# Alle compatibility-Deklarationen extrahieren
grep -r "compatibility:" skills/

# Alle Agent-Erwähnungen zählen
grep -r "claude\|gemini\|qwen\|codex\|opencode" skills/ | wc -l
```

### Schritt 5.2: Abschluss-Checkliste

```
Abschlussprüfung:
□ Alle SKILL.md Dateien haben gleiche compatibility-Liste
□ marketplace.json hat supported_agents definiert
□ Neue Agents (z.B. Qwen) überall dokumentiert
□ Skripte unterstützen alle Agents
□ Icons konsistent über alle Docs
□ Code-Integration vollständig
□ Beispiele aktuell und vollständig
```

## Werkzeuge & Vorlagen

### Vorlage: Widerspruchstabelle

```markdown
| Datei | Erwartet | Gefunden | Status | Aktion |
|-------|----------|----------|--------|--------|
| <Datei> | <Soll-Zustand> | <Ist-Zustand> | ❌/⚠️/✅ | <Korrektur> |
```

### Vorlage: Agent-Unterstützungsmatrix

```markdown
| Agent | Code | Skills | Plugins | UI | Docs | Status |
|-------|------|--------|---------|-----|------|--------|
| Claude | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ Voll |
| Gemini | ✅ | ⚠️ | ❌ | ✅ | ⚠️ | ⚠️ Teils |
| Qwen | ✅ | ❌ | ❌ | ✅ | ❌ | ❌ Lücken |
```

### Vorlage: Korrektur-Protokoll

```markdown
## Korrektur-Protokoll

**Datum:** YYYY-MM-DD
**Auslöser:** <Problem-Beschreibung>
**Betroffene Dateien:**
- <Datei 1>: <Änderung>
- <Datei 2>: <Änderung>

**Validierung:**
- [ ] Alle Dateien aktualisiert
- [ ] Konsistenz geprüft
- [ ] Build erfolgreich
- [ ] Tests bestanden
```

## Beispiele aus der Praxis

### Beispiel 1: Qwen-Integration (dieser Skill!)

**Auslöser:** "Kannst du Qwen 3.5 in Agent Deck integrieren?"

**Gefundene Widersprüche:**
- Code: ✅ Qwen vollständig implementiert
- Skills: ❌ Keine Erwähnung von Qwen
- Plugins: ❌ Nicht in supported_agents
- Icons: ❌ Qwen-Icon fehlt

**Korrektur:**
1. `skills/agent-deck/SKILL.md` → compatibility erweitert, Qwen-Docs hinzugefügt
2. `skills/agent-deck/scripts/launch-subagent.sh` → Qwen-Unterstützung dokumentiert
3. `.claude-plugin/marketplace.json` → supported_agents hinzugefügt
4. `internal/ui/styles.go` → IconQwen (🔮) und ColorBlue hinzugefügt
5. `skills/session-share/SKILL.md` → compatibility erweitert

**Ergebnis:** Qwen überall konsistent unterstützt

### Beispiel 2: Gemini "kaputt"

**Auslöser:** "gemini ist kaputt, es gibt widersprüche"

**Analyse:**
- Code: ✅ Gemini voll unterstützt
- Skills: ⚠️ Erwähnt, aber nicht in compatibility
- Plugin: ❌ Keine Metadaten

**Korrektur:**
- Alle compatibility-Listen aktualisiert
- marketplace.json Metadaten hinzugefügt

**Ergebnis:** Keine Widersprüche mehr

## Anti-Patterns (was NICHT tun)

| Anti-Pattern | Problem | Bessere Lösung |
|--------------|---------|----------------|
| Nur Code ändern | Docs veralten sofort | Immer Code + Docs zusammen |
| Metadaten ignorieren | Discoverability leidet | compatibility immer pflegen |
| Nur Haupt-Skill aktualisieren | Andere Skills veralten | ALLE Skills prüfen |
| Ohne Validierung mergen | Fehler bleiben unentdeckt | Immer Konsistenz-Check |

## Integration mit Agent Deck

### Als Sub-Agent verwenden

```bash
# Consistency-Check für ein Feature starten
agent-deck add -t "Doc Consistency Check" -c claude .
# Dann diesen Skill laden und Phase 1-5 durchgehen
```

### Als Checkliste im TUI

Speichere die Checklisten als `.claude/commands/consistency-check.md`:

```markdown
# Consistency Check

1. [ ] Alle Skills auf compatibility prüfen
2. [ ] Plugin-Metadaten aktualisieren
3. [ ] Code-Docs-Abgleich
4. [ ] Icons/Symbole prüfen
5. [ ] Build + Test
```

## Metriken für Dokumentation-Qualität

| Metrik | Ziel | Messung |
|--------|------|---------|
| **Konsistenz-Score** | 100% | Dateien mit gleichen Metadaten / Gesamt |
| **Vollständigkeit** | 100% | Dokumentierte Features / Code-Features |
| **Aktualität** | < 7 Tage | Letzte Doc-Änderung vs. Code-Änderung |
| **Widersprüche** | 0 | Gefundene Inkonsistenzen |

## Referenzen

- [Agent Deck Skill](../agent-deck/SKILL.md) - Für Session-Management während Audits
- [Session Share](../session-share/SKILL.md) - Zum Teilen von Audit-Ergebnissen
