# Consistency Checker - Quick Reference

## 5-Phasen Vorgehen (Spickzettel)

### Phase 1: Problem verstehen (2 Min)
```
□ Was genau ist kaputt?
□ Wo sind die Widersprüche?
□ Welche Dateien betroffen?
□ Seit wann besteht das Problem?
```

### Phase 2: Dateien finden (3 Min)
```bash
# Alle Skills finden
find . -name "SKILL.md"

# Plugin-Metadaten finden
find . -name "marketplace.json"

# Code-Integration prüfen
grep -r "GeminiSessionID\|QwenSessionID" internal/session/
```

### Phase 3: Analyse (5 Min)
```
□ Widerspruchstabelle erstellen
□ Metadaten extrahieren (compatibility)
□ Code vs. Docs vergleichen
□ Prioritäten setzen (P0-P3)
```

### Phase 4: Korrektur (10 Min)
```
Reihenfolge:
1. Haupt-SKILL.md (Metadaten)
2. Plugin-Metadaten (marketplace.json)
3. Skripte (*.sh)
4. Referenz-Docs
5. Andere Skills

Prinzip: ALLE Dokumente = gleiche Wahrheit
```

### Phase 5: Validierung (3 Min)
```bash
# Konsistenz prüfen
grep -r "compatibility:" skills/

# Build testen
make build
```

## Vorlagen

### Widerspruchstabelle (Copy-Paste)
```markdown
| Datei | Erwartet | Gefunden | Status | Aktion |
|-------|----------|----------|--------|--------|
|       |          |          | ❌     |        |
```

### Agent-Matrix (Copy-Paste)
```markdown
| Agent | Code | Skills | Plugins | UI | Docs | Status |
|-------|------|--------|---------|-----|------|--------|
|       | ✅   | ⚠️    | ❌      | ✅  | ⚠️   | ⚠️     |
```

## Häufige Widersprüche

| Problem | Lösung |
|---------|--------|
| compatibility veraltet | Alle Agents explizit auflisten |
| Feature nur im Code | Docs + Skills aktualisieren |
| Plugin-Metadaten leer | supported_agents hinzufügen |
| Icons fehlen | Alle Icons in config-reference.md |
| Skripte veraltet | Kommentare + Beispiele prüfen |

## Checkliste pro Korrektur

```
□ Alle SKILL.md compatibility-Listen gleich?
□ marketplace.json hat supported_agents?
□ Neue Agents überall dokumentiert?
□ Skripte unterstützen alle Agents?
□ Icons konsistent?
□ Build erfolgreich?
```

## Anti-Patterns

❌ **Nur Code ändern** → Docs veralten sofort
❌ **Metadaten ignorieren** → Discoverability leidet
❌ **Nur Haupt-Skill** → Andere Skills veralten
❌ **Ohne Validierung** → Fehler bleiben unentdeckt

✅ **Immer:** Code + Docs zusammen ändern
✅ **Immer:** ALLE Skills prüfen
✅ **Immer:** Konsistenz-Check vor Commit
