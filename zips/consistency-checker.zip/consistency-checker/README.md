# Consistency Checker Skill

Automatisierte Konsistenzprüfung für Agent Deck Dokumentation, Skills und Plugins.

## Installation

Der Skill ist bereits im Agent Deck Repository enthalten unter:
```
skills/consistency-checker/
```

## Verwendung

### Als Sub-Agent starten

```bash
# Consistency-Check für das gesamte Projekt
agent-deck add -t "Doc Consistency Check" -c claude .
# Dann diesen Skill laden
```

### Check-Skript ausführen

```bash
# Vollständige Prüfung
./skills/consistency-checker/consistency-check.sh

# Mit Details
./skills/consistency-checker/consistency-check.sh --verbose

# Spezifischen Agent prüfen
./skills/consistency-checker/consistency-check.sh --agent qwen
```

## Was wird geprüft?

### Check 1: Compatibility Declarations
- Alle SKILL.md Dateien auf konsistente `compatibility`-Listen
- Erwartet: Alle verwenden gleiche Agenten-Liste

### Check 2: Plugin Metadaten
- `marketplace.json` auf `supported_agents`
- Alle Skills registriert?

### Check 3: Code Integration
- Session-IDs für alle Agents in `instance.go`
- Tool-Erkennung in `main.go`

### Check 4: UI Integration
- Icons für alle Agents in `styles.go`
- Farben definiert?

### Check 5: Dokumentation
- Alle Agents in Haupt-Dokumentation erwähnt?
- Beispiele vollständig?

## 5-Phasen Vorgehen

Siehe [SKILL.md](SKILL.md) für das vollständige 5-Phasen Modell:

1. **Problem verstehen** (Diagnose)
2. **Dateien finden** (Parallel Search)
3. **Inhaltsanalyse** (Widerspruchserkennung)
4. **Systematische Korrektur**
5. **Validierung**

## Dateien im Skill

| Datei | Zweck |
|-------|-------|
| `SKILL.md` | Vollständige Dokumentation |
| `QUICKREF.md` | Spickzettel für schnelle Referenz |
| `consistency-check.sh` | Automatisiertes Prüfskript |
| `README.md` | Diese Datei |

## Beispiele

### Beispiel 1: Qwen-Integration prüfen

```bash
./consistency-check.sh --agent qwen
```

### Beispiel 2: Nach Feature-Add

Nachdem du ein neues Feature implementiert hast:

```bash
# Prüfen ob Docs synchron sind
./consistency-check.sh

# Bei Fehlern: SKILL.md konsultieren und Phase 4 befolgen
```

### Beispiel 3: "Irgendwas ist kaputt"

Wenn ein User meldet "X ist kaputt":

1. Skill laden
2. Phase 1 befolgen (Rückfragen stellen)
3. Check-Skript ausführen
4. Widerspruchstabelle erstellen (SKILL.md Phase 3)
5. Systematisch korrigieren (Phase 4)

## Metriken

Das Skript reportet:
- **Gesamtprüfungen**: Anzahl durchgeführter Checks
- **Bestanden**: Erfolgreiche Prüfungen
- **Fehlgeschlagen**: Kritische Inkonsistenzen
- **Warnungen**: Nicht-kritische Probleme

### Zielwerte

| Metrik | Ziel |
|--------|------|
| Fehlgeschlagen | 0 |
| Warnungen | 0 |
| Konsistenz-Score | 100% |

## Integration in CI/CD

Für zukünftige CI-Pipelines:

```yaml
# .github/workflows/docs-consistency.yml
name: Documentation Consistency

on: [push, pull_request]

jobs:
  consistency:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run Consistency Check
        run: ./skills/consistency-checker/consistency-check.sh
```

## Tipps

### Häufige Probleme

| Problem | Lösung |
|---------|--------|
| `compatibility` inkonsistent | Alle auf gleiche Liste setzen |
| Skill nicht registriert | In `marketplace.json` hinzufügen |
| Agent im Code aber nicht Docs | Docs nachpflegen |
| Icons fehlen | In `styles.go` hinzufügen |

### Best Practices

1. **Immer** Docs zusammen mit Code ändern
2. **Immer** Check-Skript vor Commit ausführen
3. **Immer** ALLE Skills prüfen, nicht nur einen
4. **Immer** Plugin-Metadaten aktuell halten

## Referenzen

- [Agent Deck Skill](../agent-deck/SKILL.md)
- [Session Share](../session-share/SKILL.md)
- [Quick Reference](QUICKREF.md)
