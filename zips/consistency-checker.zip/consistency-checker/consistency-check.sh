#!/bin/bash
# consistency-check.sh - Automated documentation consistency audit
#
# Usage: ./consistency-check.sh [options]
#
# Options:
#   --verbose    Show detailed output
#   --fix        Auto-fix common issues (dry-run by default)
#   --agent      Check specific agent (default: all)
#
# Examples:
#   ./consistency-check.sh                    # Full audit
#   ./consistency-check.sh --agent qwen       # Check Qwen only
#   ./consistency-check.sh --verbose --fix    # Verbose + auto-fix

set -e

VERBOSE=false
FIX=false
AGENT="all"

while [ $# -gt 0 ]; do
    case "$1" in
        --verbose|-v)
            VERBOSE=true
            shift
            ;;
        --fix)
            FIX=true
            shift
            ;;
        --agent)
            AGENT="$2"
            shift 2
            ;;
        *)
            shift
            ;;
    esac
done

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║     Agent Deck Consistency Checker                        ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

# Counters
TOTAL_CHECKS=0
PASSED=0
FAILED=0
WARNINGS=0

# Helper functions
log_pass() {
    echo -e "${GREEN}✓${NC} $1"
    ((PASSED++))
    ((TOTAL_CHECKS++))
}

log_fail() {
    echo -e "${RED}✗${NC} $1"
    ((FAILED++))
    ((TOTAL_CHECKS++))
}

log_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    ((WARNINGS++))
    ((TOTAL_CHECKS++))
}

log_info() {
    if [ "$VERBOSE" = true ]; then
        echo -e "${BLUE}ℹ${NC} $1"
    fi
}

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS_DIR="$(dirname "$SCRIPT_DIR")"
REPO_ROOT="$(dirname "$(dirname "$SCRIPT_DIR")")"

echo "Skills Directory: $SKILLS_DIR"
echo "Repo Root: $REPO_ROOT"
echo ""

# ============================================================================
# CHECK 1: Compatibility declarations across all SKILL.md files
# ============================================================================
echo "═══ Check 1: Compatibility Declarations ═══"

if [ "$AGENT" = "all" ] || [ "$AGENT" = "claude" ]; then
    # Extract all compatibility lines
    COMPAT_LINES=$(grep -r "^compatibility:" "$SKILLS_DIR" 2>/dev/null || true)
    
    if [ -z "$COMPAT_LINES" ]; then
        log_fail "Keine compatibility-Deklarationen gefunden"
    else
        # Check if all have same agents
        UNIQUE_COMPAT=$(echo "$COMPAT_LINES" | sort -u | wc -l)
        
        if [ "$UNIQUE_COMPAT" -gt 1 ]; then
            log_warn "Inkonsistente compatibility-Deklarationen:"
            echo "$COMPAT_LINES" | while read -r line; do
                echo "  $line"
            done
            
            if [ "$FIX" = true ]; then
                echo "  [FIX] Würde alle auf 'claude, opencode, gemini, codex, qwen' setzen"
            fi
        else
            log_pass "Alle compatibility-Deklarationen sind konsistent"
            log_info "$COMPAT_LINES"
        fi
    fi
fi

# ============================================================================
# CHECK 2: Plugin metadata (marketplace.json)
# ============================================================================
echo ""
echo "═══ Check 2: Plugin Metadaten ═══"

MARKETPLACE_FILE="$REPO_ROOT/.claude-plugin/marketplace.json"

if [ ! -f "$MARKETPLACE_FILE" ]; then
    log_fail "marketplace.json nicht gefunden: $MARKETPLACE_FILE"
else
    # Check for supported_agents
    if grep -q "supported_agents" "$MARKETPLACE_FILE"; then
        log_pass "supported_agents in marketplace.json definiert"
        
        # Extract and display
        SUPPORTED=$(grep -o '"supported_agents":\s*\[[^]]*\]' "$MARKETPLACE_FILE" || true)
        log_info "$SUPPORTED"
    else
        log_fail "supported_agents fehlt in marketplace.json"
        
        if [ "$FIX" = true ]; then
            echo "  [FIX] Würde supported_agents hinzufügen"
        fi
    fi
    
    # Check if all skills are registered
    SKILL_COUNT=$(find "$SKILLS_DIR" -name "SKILL.md" | wc -l)
    REGISTERED_COUNT=$(grep -c '"./skills/' "$MARKETPLACE_FILE" || echo "0")
    
    if [ "$SKILL_COUNT" -eq "$REGISTERED_COUNT" ]; then
        log_pass "Alle $SKILL_COUNT Skills in marketplace.json registriert"
    else
        log_warn "Skills registriert: $REGISTERED_COUNT, vorhanden: $SKILL_COUNT"
        
        if [ "$FIX" = true ]; then
            echo "  [FIX] Würde fehlende Skills hinzufügen"
        fi
    fi
fi

# ============================================================================
# CHECK 3: Code integration
# ============================================================================
echo ""
echo "═══ Check 3: Code Integration ═══"

INSTANCE_FILE="$REPO_ROOT/internal/session/instance.go"

if [ ! -f "$INSTANCE_FILE" ]; then
    log_fail "instance.go nicht gefunden"
else
    # Check for agent session IDs
    for agent in claude gemini opencode codex qwen; do
        AGENT_UPPER=$(echo "$agent" | sed 's/./\U&/')
        if grep -q "${AGENT_UPPER}SessionID" "$INSTANCE_FILE"; then
            log_pass "$agent: SessionID im Code"
        else
            log_fail "$agent: SessionID fehlt im Code"
        fi
    done
fi

# Check tool detection in main.go
MAIN_FILE="$REPO_ROOT/cmd/agent-deck/main.go"

if [ -f "$MAIN_FILE" ]; then
    echo ""
    log_info "Prüfe Tool-Erkennung in main.go..."
    
    for agent in claude gemini opencode codex qwen; do
        if grep -q "case.*$agent\|Contains.*$agent" "$MAIN_FILE"; then
            log_pass "$agent: Tool-Erkennung vorhanden"
        else
            log_warn "$agent: Tool-Erkennung könnte fehlen"
        fi
    done
fi

# ============================================================================
# CHECK 4: UI Integration (Icons & Colors)
# ============================================================================
echo ""
echo "═══ Check 4: UI Integration ═══"

STYLES_FILE="$REPO_ROOT/internal/ui/styles.go"

if [ ! -f "$STYLES_FILE" ]; then
    log_fail "styles.go nicht gefunden"
else
    # Check for agent icons
    for agent in Claude Gemini OpenCode Codex Qwen; do
        if grep -q "Icon$agent" "$STYLES_FILE"; then
            log_pass "$agent: Icon definiert"
        else
            log_warn "$agent: Icon könnte fehlen"
        fi
    done
    
    # Check for agent colors
    if grep -q "ColorBlue" "$STYLES_FILE"; then
        log_pass "ColorBlue für Qwen definiert"
    else
        log_warn "ColorBlue könnte für Qwen fehlen"
    fi
fi

# ============================================================================
# CHECK 5: Documentation completeness
# ============================================================================
echo ""
echo "═══ Check 5: Dokumentation Vollständigkeit ═══"

# Check main SKILL.md for agent mentions
MAIN_SKILL="$SKILLS_DIR/agent-deck/SKILL.md"

if [ -f "$MAIN_SKILL" ]; then
    for agent in claude gemini opencode codex qwen; do
        COUNT=$(grep -ci "$agent" "$MAIN_SKILL" || echo "0")
        if [ "$COUNT" -gt 0 ]; then
            log_pass "$agent: $COUNT Erwähnungen in SKILL.md"
        else
            log_warn "$agent: Keine Erwähnungen in SKILL.md"
        fi
    done
fi

# ============================================================================
# Summary
# ============================================================================
echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                    ZUSAMMENFASSUNG                        ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""
echo "Gesamtprüfungen: $TOTAL_CHECKS"
echo -e "${GREEN}Bestanden:${NC} $PASSED"
echo -e "${RED}Fehlgeschlagen:${NC} $FAILED"
echo -e "${YELLOW}Warnungen:${NC} $WARNINGS"
echo ""

if [ "$FAILED" -eq 0 ] && [ "$WARNINGS" -eq 0 ]; then
    echo -e "${GREEN}✓ Alles konsistent!${NC}"
    exit 0
elif [ "$FAILED" -eq 0 ]; then
    echo -e "${YELLOW}⚠ Keine kritischen Fehler, aber Warnungen vorhanden${NC}"
    exit 0
else
    echo -e "${RED}✗ Inkonsistenzen gefunden!${NC}"
    echo ""
    echo "Nächste Schritte:"
    echo "  1. Obige Fehler beheben"
    echo "  2. Skript erneut ausführen: ./consistency-check.sh"
    echo "  3. Bei Auto-Fix: ./consistency-check.sh --fix"
    exit 1
fi
