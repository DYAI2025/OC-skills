#!/bin/bash
# skill-db.sh - Agent Deck Skill Database Manager
#
# Usage: skill-db.sh <command> [options]
#
# Commands:
#   list, ls         List all skills
#   show <id>        Show skill details
#   install <id>     Install a skill
#   remove <id>      Remove a skill
#   search <query>   Search skills
#   sync             Sync with repo
#   status           Show database status

set -e

SKILL_DB="$HOME/.agent-deck/skill-db"
REGISTRY="$SKILL_DB/registry.json"
REPO_SKILLS="/home/dyai/Dokumente/Pers.Tests-Page/social-role/DYAI_home/DEV/CLI_IDE/agent-deck/agent-deck/skills"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Helper functions
log_info() { echo -e "${BLUE}ℹ${NC} $1"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_warn() { echo -e "${YELLOW}⚠${NC} $1"; }
log_error() { echo -e "${RED}✗${NC} $1"; }

# Check if registry exists
check_registry() {
    if [ ! -f "$REGISTRY" ]; then
        log_error "Registry not found: $REGISTRY"
        exit 1
    fi
}

# List all skills
cmd_list() {
    check_registry
    
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║              Agent Deck Skills                           ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    # Extract skills using jq
    if command -v jq &> /dev/null; then
        jq -r '.skills[] | "\(.id)|\(.name)|\(.version)|\(.category)|\(.installed)"' "$REGISTRY" | \
        while IFS='|' read -r id name version category installed; do
            if [ "$installed" = "true" ]; then
                echo -e "${GREEN}✓${NC} $name v$version [$category]"
            else
                echo "  $name v$version [$category]"
            fi
        done
    else
        # Fallback without jq
        log_info "Installing jq recommended for better output"
        grep -o '"id": "[^"]*"' "$REGISTRY" | cut -d'"' -f4 | while read -r id; do
            echo "  $id"
        done
    fi
    
    echo ""
    
    # Show stats
    if command -v jq &> /dev/null; then
        total=$(jq '.metadata.total_skills' "$REGISTRY")
        official=$(jq '.metadata.official_count' "$REGISTRY")
        community=$(jq '.metadata.community_count' "$REGISTRY")
        custom=$(jq '.metadata.custom_count' "$REGISTRY")
        
        echo "Stats: $total total ($official official, $community community, $custom custom)"
    fi
}

# Show skill details
cmd_show() {
    local skill_id="$1"
    
    if [ -z "$skill_id" ]; then
        log_error "Usage: skill-db.sh show <skill-id>"
        exit 1
    fi
    
    check_registry
    
    if command -v jq &> /dev/null; then
        skill_data=$(jq -r ".skills[] | select(.id == \"$skill_id\")" "$REGISTRY")
        
        if [ -z "$skill_data" ] || [ "$skill_data" = "null" ]; then
            log_error "Skill not found: $skill_id"
            exit 1
        fi
        
        echo "╔══════════════════════════════════════════════════════════╗"
        echo "║  Skill: $skill_id"
        echo "╚══════════════════════════════════════════════════════════╝"
        echo ""
        
        jq -r '"Name: " + .name,
               "Version: " + .version,
               "Author: " + .author,
               "Description: " + .description,
               "Category: " + .category,
               "Source: " + .source,
               "Installed: " + (.installed | tostring),
               "Compatibility: " + (.compatibility | join(", ")),
               "Tags: " + (.tags | join(", "))' <<< "$skill_data"
    else
        log_error "jq required for this command"
        exit 1
    fi
}

# Search skills
cmd_search() {
    local query="$1"
    
    if [ -z "$query" ]; then
        log_error "Usage: skill-db.sh search <query>"
        exit 1
    fi
    
    check_registry
    
    echo "Searching for: $query"
    echo ""
    
    if command -v jq &> /dev/null; then
        jq -r --arg q "$query" '
            .skills[] | 
            select(
                (.name | ascii_downcase | contains($q | ascii_downcase)) or
                (.description | ascii_downcase | contains($q | ascii_downcase)) or
                (.tags | map(ascii_downcase) | any(contains($q | ascii_downcase)))
            ) |
            "\(.id)|\(.name)|\(.description)"
        ' "$REGISTRY" | \
        while IFS='|' read -r id name desc; do
            echo -e "${GREEN}✓${NC} $name ($id)"
            echo "   $desc"
            echo ""
        done
    else
        grep -i "$query" "$REGISTRY"
    fi
}

# Sync with repo
cmd_sync() {
    log_info "Syncing with repo..."
    
    if [ ! -d "$REPO_SKILLS" ]; then
        log_error "Repo skills directory not found: $REPO_SKILLS"
        exit 1
    fi
    
    # Copy new skills from repo
    for skill_dir in "$REPO_SKILLS"/*/; do
        if [ -d "$skill_dir" ]; then
            skill_name=$(basename "$skill_dir")
            dest="$SKILL_DB/official/$skill_name"
            
            if [ ! -d "$dest" ]; then
                log_info "Copying $skill_name..."
                cp -r "$skill_dir" "$dest"
                log_success "Added: $skill_name"
            else
                # Check for updates
                log_info "Checking $skill_name..."
                # Simple timestamp check (could be improved)
                if [ "$skill_dir" -nt "$dest" ]; then
                    log_info "Updating $skill_name..."
                    cp -r "$skill_dir" "$dest"
                    log_success "Updated: $skill_name"
                fi
            fi
        fi
    done
    
    log_success "Sync complete!"
}

# Show status
cmd_status() {
    check_registry
    
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║          Agent Deck Skill Database Status                ║"
    echo "╚══════════════════════════════════════════════════════════╝"
    echo ""
    
    # Database info
    echo "Database: $SKILL_DB"
    echo "Registry: $REGISTRY"
    echo ""
    
    # File stats
    if [ -f "$REGISTRY" ]; then
        echo "Registry size: $(du -h "$REGISTRY" | cut -f1)"
        echo "Last modified: $(stat -c %y "$REGISTRY" 2>/dev/null || stat -f %Sm "$REGISTRY" 2>/dev/null)"
    fi
    echo ""
    
    # Skill counts
    echo "Skills by location:"
    echo "  Official:  $(find "$SKILL_DB/official" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)"
    echo "  Community: $(find "$SKILL_DB/community" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)"
    echo "  Custom:    $(find "$SKILL_DB/custom" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)"
    echo ""
    
    # Metadata
    if command -v jq &> /dev/null; then
        echo "Metadata:"
        jq -r '"  Total: " + (.metadata.total_skills | tostring),
                "  Official: " + (.metadata.official_count | tostring),
                "  Community: " + (.metadata.community_count | tostring),
                "  Custom: " + (.metadata.custom_count | tostring)' "$REGISTRY"
    fi
}

# Show help
cmd_help() {
    echo "Agent Deck Skill Database Manager"
    echo ""
    echo "Usage: skill-db.sh <command> [options]"
    echo ""
    echo "Commands:"
    echo "  list, ls         List all skills"
    echo "  show <id>        Show skill details"
    echo "  install <id>     Install a skill"
    echo "  remove <id>      Remove a skill"
    echo "  search <query>   Search skills"
    echo "  sync             Sync with repo"
    echo "  status           Show database status"
    echo "  help             Show this help"
    echo ""
    echo "Examples:"
    echo "  skill-db.sh list"
    echo "  skill-db.sh show consistency-checker"
    echo "  skill-db.sh search documentation"
    echo "  skill-db.sh sync"
}

# Main command router
case "${1:-help}" in
    list|ls)
        cmd_list
        ;;
    show)
        cmd_show "$2"
        ;;
    install)
        log_info "Install command - coming soon"
        ;;
    remove)
        log_info "Remove command - coming soon"
        ;;
    search)
        cmd_search "$2"
        ;;
    sync)
        cmd_sync
        ;;
    status)
        cmd_status
        ;;
    help|--help|-h)
        cmd_help
        ;;
    *)
        log_error "Unknown command: $1"
        cmd_help
        exit 1
        ;;
esac
