---
name: multi-agent-diagnose
description: Strukturierte Diagnose für Multi-Agent Skill-Stacks. Verwenden bei: "Gemini/Qwen ist kaputt", Kompatibilitäts-Drift, Hook-Gaps, Schema-Mismatch, Orchestrator-Timing, Policy-Konflikten. Liefert Szenario-Baum, Scoring, Tests und Rollout-Gates.
compatibility: claude, opencode, gemini, codex, qwen
version: 1.0.0
based_on: FlashDocs skill_multi-agent-detector.md + Agent Deck Consistency Checker
---

# Multi-Agent Diagnose

**Version:** 1.0 | **Methode:** DRA (Diagnose → Root-Cause → Action)

## Wann verwenden?

| Symptom | Verdacht | Aktion |
|---------|----------|--------|
| "Gemini/Qwen ist kaputt" | Support-Drift | → Phase 1: SSOT prüfen |
| UI sagt "nicht unterstützt", Script kann es | Metadaten-Drift | → Phase 2: Artefakte vergleichen |
| Feature nur in Claude, nicht anderen | Hook-Gap | → Phase 3: Capability Probe |
| Parser-Fehler, stille Defaults | Schema-Mismatch | → Phase 4: Format-Check |
| Launcher hängt, timeout | Timing-Bug | → Phase 5: Readiness-Check |
| "Nicht erlaubter Befehl" | Policy-Konflikt | → Phase 6: Guardrail-Check |
| Flaky Outputs, "works on my agent" | Non-Determinismus | → Phase 7: Variance-Check |

**Nicht verwenden** bei:
- Eindeutig lokaler Implementierungsfehler (single agent)
- Reine Feature-Entwicklung ohne Diagnose-Bedarf

---

## Phase 1: SSOT/Context Anchor (HARD REQUIREMENT)

### Schritt 1.1: SSOT identifizieren

```bash
# SSOT Pfad prüfen
ls -la ~/.agent-deck/config/agents.yaml

# SSOT laden und validieren
python3 ~/.agent-deck/bin/agent-deck-global.py get-agents
```

**Wenn keine SSOT existiert:**
- Als Root-Cause dokumentieren: "Fehlende Single Source of Truth"
- Fix vorschlagen: SSOT erstellen (siehe `agents.yaml` Template)

### Schritt 1.2: MISSING/ASSUMPTION Protocol

```markdown
## MISSING
- [ ] Konkrete Agent-Fähigkeiten (Hook-API vorhanden?)
- [ ] Policy-Texte (no-rewrite, audit-required?)
- [ ] Runtime-Umgebung (PATH, ENV, non-interactive?)

## ASSUMPTIONS
- ASSUMPTION: Qwen hat keine Hook-API → Impact: Wrapper-Mode erforderlich
- ASSUMPTION: Gemini unterstützt determinism controls → Impact: Tests können flaky sein
```

---

## Phase 2: Kontext & Zerlegung

### Schritt 2.1: Komponentendiagramm (Textform)

```
┌─────────────┐    git status    ┌─────────────┐
│   Agent     │ ──────────────── │   Shell     │
│  (Claude)   │                  │   (bash)    │
└─────────────┘                  └─────────────┘
       │                                │
       │  Hook (PreToolUse)             │
       └────────────────────────────────┘
                rtk git status
```

**Komponenten:**
1. Agent (Claude/Gemini/Qwen/Codex/OpenCode)
2. Plugin/Skill (agent-deck, RTK, etc.)
3. Orchestrator (Agent Deck TUI/CLI)
4. CLI (Shell, PTY)
5. Hook-System (nur Claude)
6. Wrapper/Proxy (RTK)
7. Config/Manifest (agents.yaml)
8. Marketplace/Index (registry.json)

### Schritt 2.2: Problemklassen

| Klasse | Symptome | Check |
|--------|----------|-------|
| **Format/Schema** | Parser-Fehler, stille Defaults | YAML/JSON/TOML validieren |
| **Policy/Guardrail** | Feature geblockt, Audit fehlt | Consent-Gate prüfen |
| **Tool/Runtime** | CLI nicht gefunden, PATH falsch | `which <agent>` |
| **State/Timing** | Launcher hängt, timeout | Readiness-Sentinel |
| **Drift** | Docs ≠ Code ≠ Runtime | Set-Equality-Check |
| **Non-Determinismus** | Flaky, "works on my agent" | Golden-Tests |

---

## Phase 3: Plan-and-Solve Blueprint

### Aufgabenplan

```
1. Diagnose
   □ SSOT laden
   □ Artefakte extrahieren (SKILL.md, marketplace.json, Scripts)
   □ Capability-Probe (has_hooks?)

2. Fix-Design
   □ Root-Cause identifizieren
   □ Fix-Pattern wählen (SSOT, Wrapper, Schema, etc.)
   □ Fallback definieren (Manual-Mode?)

3. Validierung
   □ Test definieren (positiv + negativ)
   □ Exit-Kriterien setzen

4. Rollout-Guards
   □ CI-Gate (check-compatibility)
   □ Version-Bump (wenn Schema-Änderung)
   □ Changelog
```

### Exit-Kriterien

| Kriterium | Messung | Ziel |
|-----------|---------|------|
| **drift-frei** | Set-Equality-Check | Alle Quellen = gleiches Agent-Set |
| **hook-fallback** | Capability-Navigation | Hooks → Hook-Integration, sonst Wrapper |
| **tests-grün** | Linter + Smoke | Exit-Code 0 |

---

## Phase 4: Szenario-Baum (6 Äste)

### S1: Hook-Abhängigkeit (RTK nur in Claude)

**Symptom:** Keine Token-Savings in Gemini/Qwen

**Root-Cause-Hypothesen:**
- H1 (Plausibilität: 5): Kein Hook-System im Ziel-Agenten
- H2 (3): RTK nicht im PATH/ENV (non-interactive shell)
- H3 (2): Hook deaktiviert in Config

**Fix-Pattern:** Capability Probe + Progressive Enhancement

```bash
# Capability prüfen
python3 ~/.agent-deck/bin/agent-deck-global.py get-capability gemini

# Wenn has_hooks=false → Wrapper-Mode
echo "Wrapper-Mode erforderlich: rtk <cmd>"
```

**Validation-Tests:**
- Test1: `git status` → log: executed="rtk git status"
- Test2 (negativ): Hooks deaktiviert → erwarte Wrapper-Path aktiv
- Test3: Rekursionstest: kein "rtk rtk git status"

**Residualrisiken:**
- Wrapper sieht keine direkten Tool-API-Calls
- Shell-Aliases werden evtl. nicht geladen

---

### S2: Dokumentations-/Metadaten-Drift

**Symptom:** UI sagt "Agent nicht unterstützt", Script kann es

**Root-Cause-Hypothesen:**
- H1 (5): SKILL.md `compatibility` veraltet
- H2 (4): marketplace.json `supported_agents` fehlt
- H3 (4): Keine CI-Gates für Set-Gleichheit

**Fix-Pattern:** SSOT + Generator + CI Set-Equality-Gate

```bash
# SSOT generieren
python3 ~/.agent-deck/bin/agent-deck-global.py generate

# Kompatibilität prüfen
python3 ~/.agent-deck/bin/agent-deck-global.py check-compatibility
```

**Validation-Tests:**
- Test1: Linter bestätigt set-equality
- Test2: E2E smoke: für jeden Agent existiert Launch-Beispiel
- Test3 (negativ): Entferne "qwen" → CI muss failen

**Residualrisiken:**
- Multi-Repo ohne zentrales Gate
- Caches zeigen alte Metadaten

---

### S3: Format/Schema-Mismatch

**Symptom:** Parsing-Fehler oder stille Defaults

**Root-Cause-Hypothesen:**
- H1 (4): Kein kanonisches Schema
- H2 (3): Loose parsing verschluckt Felder
- H3 (2): Encoding/Non-ASCII bricht Parser

**Fix-Pattern:** Canonical Schema + Adapter + Strict-Validation

```bash
# Schema validieren
python3 -c "
import json, sys
with open('~/.agent-deck/config/agents.yaml') as f:
    import yaml
    data = yaml.safe_load(f)
    # Validiere required fields
    assert 'agents' in data
    for a in data['agents']:
        assert 'id' in a
        assert 'display_name' in a
print('Schema OK')
"
```

**Validation-Tests:**
- Test1: 5 Fuzz-Cases → alle validieren JSON-Schema
- Test2: Roundtrip yaml→json→yaml
- Test3 (negativ): missing `supported_agents` → Validator muss failen

---

### S4: State/Timing/Orchestration-Bug

**Symptom:** `--wait` blockiert, Sessions leaken

**Root-Cause-Hypothesen:**
- H1 (5): Readiness-Detection basiert auf Claude-spezifischen Phrasen
- H2 (4): stdout/stderr getrennt, readiness in stderr verpasst
- H3 (3): Race beim MCP-Attach

**Fix-Pattern:** Sentinel-Handshake + Tool-Specific-Adapter

```bash
# Readiness-Sentinel testen
for agent in claude gemini qwen codex opencode; do
    echo "Testing $agent..."
    # Sende readiness_sentinel, warte auf Response
done
```

**Validation-Tests:**
- Test1: Harness startet jedes Tool → Readiness in ≤N Sekunden
- Test2: Inject-Failure → Timeout muss Logs sammeln + Cleanup
- Test3: MCP-Attach → keine Deadlocks

---

### S5: Policy/Guardrail-Konflikt

**Symptom:** Feature geblockt, Audit findet nichts

**Root-Cause-Hypothesen:**
- H1 (4): Security-Policy untersagt unsichtbare Interception
- H2 (5): Fehlender Audit-Trail macht Feature unzulässig
- H3 (3): Prompt-Instruktionen widersprüchlich

**Fix-Pattern:** Diff-Preview + Consent-Gate + Allowlist

```markdown
## Policy-Check
- [ ] Consent-Gate aktiv?
- [ ] Audit-Log: original→rewritten→executed?
- [ ] Allowlist definiert?
```

**Validation-Tests:**
- Test1: Ohne Consent → kein Rewrite executed
- Test2: Audit-Log enthält alle 3 Stufen
- Test3 (negativ): Nicht erlaubtes Kommando → Passthrough + Warning

---

### S6: Non-Determinismus/Variance

**Symptom:** Flaky Automation, gleicher Input → anderer Output

**Root-Cause-Hypothesen:**
- H1 (4): Sampling-Parameter nicht fixiert
- H2 (4): Prompt-Kontext driftet je Agent
- H3 (3): Hidden-State/Context-Leakage

**Fix-Pattern:** Determinism-Controls + Golden-Tests + Idempotence

```bash
# Idempotence-Check
rewrite1=$(echo "git status" | rtk-rewrite)
rewrite2=$(echo "$rewrite1" | rtk-rewrite)
[ "$rewrite1" = "$rewrite2" ] && echo "Idempotent OK"
```

**Validation-Tests:**
- Test1: 100 Wiederholungen → identischer Rewrite
- Test2: Cross-Agent-Parity → Unterschiede innerhalb Policy
- Test3: Idempotence: rewrite(rewrite(cmd)) == rewrite(cmd)

---

## Phase 5: Scoring (PoT)

### Scoring-Modell

```python
# ~/.agent-deck/bin/score_scenarios.py
criteria = {
    'frequency': 0.25,    # Wie oft tritt Problem auf?
    'likelihood': 0.25,   # Wahrscheinlichkeit der Hypothese
    'detectability': 0.20, # 10 = schwer zu entdecken
    'impact': 0.20,       # Business-Impact
    'fix_cost': 0.10      # 10 = sehr teuer
}

score = sum(weight * value for weight, value in zip(criteria.values(), values))
```

### Beispiel-Scoring

| Szenario | freq | like | detect | impact | cost | **Score** |
|----------|------|------|--------|--------|------|-----------|
| S1 (Hook) | 7 | 8 | 6 | 8 | 5 | **7.05** |
| **S2 (Drift)** | **8** | **9** | **7** | **7** | **3** | **7.35** ← Winner |
| S3 (Schema) | 6 | 6 | 5 | 6 | 4 | 5.60 |
| S4 (Timing) | 5 | 6 | 4 | 6 | 6 | 5.35 |
| S5 (Policy) | 4 | 5 | 8 | 9 | 7 | 6.35 |
| S6 (Variance) | 6 | 5 | 7 | 7 | 8 | 6.35 |

**Winner: S2 (Dokumentations-Drift)** – passt direkt auf "Gemini ist kaputt, Widersprüche in Skills/Plugins"

---

## Phase 6: Verification & Bias-Control

### Verifikationsliste

| Claim | Typ | Evidenz |
|-------|-----|---------|
| "S2 ist Winner" | Fakt | Scoring-Rechnung oben |
| "Drift ist häufig" | Interpretation | Erfahrungswert |
| "SSOT hilft" | Logik | Prinzip P1 |

### Bias-Report

| Bias | Mitigation |
|------|------------|
| Confirmation-Bias | ≥6 Gegenhypothesen |
| Overconfidence | MISSING/ASSUMPTION explizit |
| Availability | Szenario-Bibliothek nutzen |

### Grenzen

| Unsolved-Case | Warum |
|---------------|-------|
| Locked-Down-Agent ohne Interception | Kein Hook/Wrapper möglich |
| Policy: no-rewrite AND no-logs | Konflikt nicht auflösbar |
| Vendor-Updates brechen Readiness | Ohne stabile API fragil |

---

## Phase 7: Synthese & Delivery

### Taxonomie

```
Multi-Agent-Probleme
├── Format/Schema-Mismatch
├── Context-Anchor/SSOT-Failure
├── Policy/Guardrail-Conflict
├── Tool/Runtime-Failure
├── State/Timing/Orchestration-Bug
├── Capability-Gap/Missing-Skill
├── Non-Determinismus/Variance
└── Verification/Testing-Gaps
```

### Playbooks (Composable Patterns)

| Pattern | Prinzipien | Use-When |
|---------|------------|----------|
| **C1** | P1 + PR1 + PR8 | Doc/ Metadata-Drift |
| **C2** | P2 + P4 + P11 + PR3 | Hook→Wrapper-Portierung |
| **C3** | P5 + P6 + PR6 + PR7 | LLM-Transforms + Compliance |

### Rollout-Strategie

```bash
# CI-Gates
./scripts/generate-agent-manifest.sh --check

# Smoke-Tests
for agent in claude gemini qwen codex opencode; do
    echo "Testing $agent..."
    # Minimal-Test
done

# Version-Bump + Changelog
# agents.yaml: version: "2.0.0"
```

---

## Quick-Reference (Spickzettel)

### 5-Minuten-Diagnose

```bash
# 1. SSOT prüfen (1 Min)
agent-agents

# 2. Kompatibilität (1 Min)
agent-check

# 3. Capability (1 Min)
agent-capability qwen

# 4. Artefakte (1 Min)
cat skills/*/SKILL.md | grep compatibility

# 5. Fix (1 Min)
agent-generate
```

### Häufigste Fixes

| Problem | Fix |
|---------|-----|
| Drift | `agent-generate` |
| Hook-Gap | Wrapper-Mode |
| Schema | Canonical-JSON |
| Timing | Sentinel-Handshake |
| Policy | Consent-Gate |
| Variance | Golden-Tests |

---

## Referenzen

- [Consistency Checker Skill](../consistency-checker/SKILL.md)
- [Agent Deck Global](../../docs/GLOBAL_CONFIG.md)
- [DRA Library](references/dra-library.md)
- [Principles](references/principles.md)
