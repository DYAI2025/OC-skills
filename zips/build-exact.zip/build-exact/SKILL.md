---
name: build-exact
description: Complete development framework: Brainstorm → Plan → Execute in one unified process
compatibility: claude, opencode, gemini, codex, qwen
version: 1.0.0
author: OpenClawMD (based on Claude Superpowers)
pattern: protocol
---

# Build:Exact - Complete Development Framework

**Announce at start:** "I'm using the Build:Exact skill to take your idea from concept to implementation."

## Overview

Combines 3 phases into one seamless process:
1. **Brainstorming** - Transform rough ideas into designs
2. **Planning** - Generate bite-sized implementation tasks  
3. **Execution** - Batch execution with review checkpoints

## The Complete Process

### PHASE 1: Brainstorming Ideas Into Designs

**Announce:** "Starting Phase 1: Brainstorming. I'll refine your idea into a design."

#### Step 1.1: Understanding
- Check current project state in working directory
- Ask ONE question at a time to refine the idea
- Prefer multiple choice when possible
- Gather: Purpose, constraints, success criteria

**Example Questions:**
```
1. "What's the main problem this feature solves?"
2. "Are there any technical constraints I should know about?"
3. "How will you measure success for this feature?"
```

#### Step 1.2: Exploration
- Propose 2-3 different approaches
- For each: Core architecture, trade-offs, complexity assessment
- Ask which approach resonates

**Example:**
```markdown
## Approach A: Simple Integration
- Core: Add to existing module
- Trade-off: Less flexible, faster
- Complexity: Low (2-3 hours)

## Approach B: Standalone Service  
- Core: New microservice
- Trade-off: More flexible, more ops
- Complexity: Medium (1-2 days)

Which approach resonates more with your needs?
```

#### Step 1.3: Design Presentation
- Present in 200-300 word sections
- Cover: Architecture, components, data flow, error handling, testing
- Ask after each section: "Does this look right so far?"

**Output:** `docs/design/YYYY-MM-DD-feature-design.md`

#### Step 1.4: Worktree Setup (when design approved)
**Announce:** "Design approved! Setting up isolated workspace using Git Worktrees."

```bash
# Create worktree for implementation
git worktree add -b feature/$(slug) ../worktrees/$(slug)
cd ../worktrees/$(slug)
```

#### Step 1.5: Planning Handoff
**Ask:** "Ready to create the implementation plan?"

When confirmed → Proceed to PHASE 2

---

### PHASE 2: Writing Plans

**Announce:** "Starting Phase 2: Writing Plans. I'll create detailed implementation tasks."

**Save to:** `docs/plans/YYYY-MM-DD-feature-name.md`

#### Plan Document Structure

```markdown
# [Feature Name] Implementation Plan

> **For Claude:** Use `build:exact` Phase 3 to implement this plan task-by-task.

**Goal:** [One sentence describing what this builds]

**Architecture:** [2-3 sentences about approach]

**Tech Stack:** [Key technologies/libraries]

---

### Task 1: [Component Name]

**Files:**
- Create: `exact/path/to/file.py`
- Modify: `exact/path/to/existing.py:123-145`
- Test: `tests/exact/path/to/test.py`

**Step 1: Write the failing test**

```python
def test_specific_behavior():
    result = function(input)
    assert result == expected
```

**Step 2: Run test to verify it fails**

```bash
pytest tests/path/test.py::test_name -v
```
Expected: FAIL with "function not defined"

**Step 3: Write minimal implementation**

```python
def function(input):
    return expected
```

**Step 4: Run test to verify it passes**

```bash
pytest tests/path/test.py::test_name -v
```
Expected: PASS

**Step 5: Commit**

```bash
git add tests/path/test.py src/path/file.py
git commit -m "feat: add specific feature"
```

---

[Repeat for each task]
```

#### Bite-Sized Task Rules
- Each step is ONE action (2-5 minutes)
- "Write the failing test" - one step
- "Run it to make sure it fails" - one step
- "Implement the minimal code" - one step
- "Run the tests" - one step
- "Commit" - one step

#### Execution Handoff
**After saving plan, offer choice:**

```
Plan complete and saved to `docs/plans/<filename>.md`. Two execution options:

**1. Subagent-Driven (this session)** - I dispatch fresh subagent per task, review between tasks, fast iteration

**2. Parallel Session (separate)** - Open new session with executing-plans, batch execution with checkpoints

Which approach?
```

When confirmed → Proceed to PHASE 3

---

### PHASE 3: Executing Plans

**Announce:** "Starting Phase 3: Executing Plans. I'll implement tasks in batches with review checkpoints."

#### Step 3.1: Load and Review Plan
```bash
cat docs/plans/YYYY-MM-DD-feature-name.md
```

**Review critically:**
- Identify any questions or concerns
- If concerns: Raise them before starting
- If no concerns: Create TodoWrite and proceed

#### Step 3.2: Execute Batch (default: first 3 tasks)

For each task:
1. Mark as `in_progress`
2. Follow each step exactly (plan has bite-sized steps)
3. Run verifications as specified
4. Mark as `completed`

#### Step 3.3: Report
When batch complete:

```markdown
## Batch Complete ✅

**Implemented:**
- Task 1: [Component A] - DONE
- Task 2: [Component B] - DONE  
- Task 3: [Component C] - DONE

**Verification Output:**
```bash
pytest tests/ -v
# 15 passed in 2.3s
```

**Ready for feedback.**
```

#### Step 3.4: Continue
Based on feedback:
- Apply changes if needed
- Execute next batch
- Repeat until complete

#### Step 3.5: Complete Development
After all tasks complete and verified:

**Announce:** "Implementation complete! Using Finishing a Development Branch skill to complete this work."

**Final checks:**
```bash
# Run full test suite
pytest tests/ -v

# Check code quality
ruff check src/

# Present options:
1. Create Pull Request
2. Merge to main
3. Deploy to staging
```

---

## When to Revisit Earlier Phases

### During Phase 2 or 3 → Return to Phase 1 when:
- Partner reveals new constraint
- Validation shows fundamental gap in requirements
- Partner questions approach

### During Phase 3 → Return to Phase 2 when:
- Plan has critical gaps
- Tasks are unclear or impossible to execute
- New approach needed

### During Phase 3 → STOP and Ask when:
- Hit a blocker mid-batch (missing dependency, test fails)
- Instruction unclear
- Verification fails repeatedly

**Don't force through blockers - stop and ask.**

---

## Quick Reference

| Phase | Input | Output | Key Rule |
|-------|-------|--------|----------|
| **1. Brainstorming** | Rough idea | Approved design | One question at a time |
| **2. Planning** | Design | Task list | Bite-sized steps |
| **3. Execution** | Plan | Working code | Batch + review |

---

## Related Skills

- **Git Worktrees:** For isolated development branches
- **Subagent-Driven Development:** For parallel task execution
- **Finishing a Development Branch:** For completion workflow

---

## Remember

### Phase 1 (Brainstorming)
- One question per message
- Apply YAGNI ruthlessly
- Explore 2-3 alternatives before settling
- Present incrementally, validate as you go
- Go backward when needed

### Phase 2 (Planning)
- Exact file paths always
- Complete code in plan (not "add validation")
- Exact commands with expected output
- DRY, YAGNI, TDD, frequent commits

### Phase 3 (Execution)
- Review plan critically first
- Follow plan steps exactly
- Don't skip verifications
- Between batches: just report and wait
- Stop when blocked, don't guess

---

## Examples

### Example 1: New Feature Request

**User:** "I want to add user authentication to my app"

**Build:Exact Response:**
```
I'm using the Build:Exact skill to take your idea from implementation.

Starting Phase 1: Brainstorming. I'll refine your idea into a design.

First question: What type of authentication do you need?
A) Email/password with session cookies
B) OAuth (Google/GitHub)
C) Both A and B
D) Something else (tell me more)
```

### Example 2: Bug Fix

**User:** "The search feature is slow"

**Build:Exact Response:**
```
I'm using the Build:Exact skill to take your idea from concept to implementation.

Starting Phase 1: Brainstorming.

Let me understand the issue:

1. How slow is "slow"? 
   A) 1-2 seconds (annoying)
   B) 5-10 seconds (painful)
   C) 30+ seconds (unusable)

2. When does it happen?
   A) Every search
   B) Only with certain queries
   C) Only under load
```

### Example 3: Refactoring

**User:** "I need to refactor the payment module"

**Build:Exact Response:**
```
I'm using the Build:Exact skill to take your idea from concept to implementation.

Starting Phase 1: Brainstorming.

What's the main driver for refactoring?
A) Code is hard to understand
B) Adding new features is slow
C) Performance issues
D) Preparing for scale
E) Other (explain)
```

---

## Version History

- **1.0.0** - Initial release combining Brainstorming + Planning + Execution
